#include <windows.h>  // for MS Windows
#include <GL/glut.h>  // GLUT, include glu.h and gl.h
#include <math.h>     // For using sin() and cos() functions
#include <stdbool.h>
#include<iostream>
#include<sstream>
// Player Properties
float playerX = -0.875f;
float playerY = 0.675f;
float playerRadius = 0.018f;
float velocityY = 0.0f;
float gravity = -0.0015f;
float jumpForce = 0.025f;// Stronger jump for platform-to-platform
bool isOnGround = false;
float topLeftPlatformSpeed = 0.001f;
bool movingRight = true;
bool movingleft = true;
float topRightPlatformSpeed = 0.001f;
float movingCircleY = 0.2f;         // Starting Y position of the circle

float movingCircleSpeed = 0.002f;   // Speed of vertical movement
bool movingUpCircle = true;         // Direction flag for movement
// Cloud movement variables
float cloud1X = -0.8f;
float cloud2X = 0.0f;
float cloud3X = 0.6f;
float cloudSpeed = 0.002f; // Speed of cloud movement
bool moveRightCloud1 = true,moveRightCloud2 = true,moveRightCloud3 = true;

//for 2nd part
// Moving circle variables
float movingCircleX = -0.07f;      // Starting Y position
float movingCircleXSpeed = 0.002f;  // Speed of vertical movement
bool movingDown = true;            // Direction flag (true = down, false = up)

float movingCircleZ = -0.29f;      // Starting Y position
float movingCircleZSpeed = 0.005f;  // Speed of vertical movement
bool movingDownZ = true;
bool levelComplete = false;

// Define the position and size of the flag
float flagX = 0.92f;  // X position of the flag
float flagY = 0.33f;  // Y position of the flag (top of the pole)
float flagWidth = 0.04f;  // Width of the flag
float flagHeight = 0.04f;  // Height of the fla

bool moveLeft = false;
bool moveRight = false;

// Scoring system
int score = 0;                // Player score
float blockPositions[] = { -0.8f, -0.5f, -0.4f, 0.0f, 0.1f, 0.25,0.58f, 0.84f, 1.0f }; // Blocks positions
bool blocksPassed[9] = { false };  // Tracks if player has passed each block

void resetPlayer() {
    playerX = -0.875f;  // Reset to initial X position
    playerY = 0.675f;  // Reset to initial Y position
    velocityY = 0.0f; // Reset vertical velocity
    score = 0;        // Reset the score to 0
    for (int i = 0; i < 8; i++) {
        blocksPassed[i] = false; // Reset passed blocks
    }
}



//  Play background sound when the game starts
void playBackgroundSound() {
    PlaySound(TEXT("bg.wav"), NULL, SND_ASYNC | SND_LOOP);
}

//  Play failure sound when player falls
void playFailSound() {
    PlaySound(TEXT("faill.wav"), NULL, SND_ASYNC);
}

// Play level completion sound when player wins
void playLevelCompleteSound() {
    PlaySound(TEXT("levelcom.wav"), NULL, SND_ASYNC);
}
// Function to draw a text message
void drawText(const char* text, float x, float y) {
    glColor3f(1.0f, 1.0f, 1.0f); // White color
    glRasterPos2f(x, y);
    while (*text) {
        glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, *text++);
    }
}
// Function to check if player reaches the end
bool checkLevelComplete() {
    return (playerX + playerRadius >= flagX && playerY >= flagY);
}
struct Platform {
    float left, right, top, bottom;
};

// First Rectangle (Upper Platform)
Platform firstPlatform = {-0.95f, -0.80f, 0.65f, 0.6f};

// Second Rectangle (Lower Platform)
Platform secondPlatform = {-0.95f, -0.7f, 0.4f, 0.35f};

// Bottom Brick Part
Platform bottomPlatform = {-1.0f, 1.0f, 0.1f, 0.0f};

// New platforms for jumping
Platform topLeftPlatform = {-0.5f, -0.4f, 0.18f, 0.15f}; // Left top platform
Platform topRightPlatform = {-0.3f, -0.2f, 0.18f, 0.15f}; // Right top platform

// for first piller
Platform firstpillerPlatform = {0.01f, 0.08f, 0.25f, 0.1f};


Platform firsttopLeftPlatform = {0.1f, 0.17f, 0.33f, 0.3f}; // Left top platform
Platform secondtopLeftPlatform = {0.23f, 0.30f, 0.33f, 0.3f}; // Left top platform

Platform secondpillerPlatform = {0.8f, 0.85f, 0.25f, 0.1f};

Platform lasttopPlatform = {0.9f, 0.95f, 0.25f, 0.22f};
// Updated Lava Triangle Bounds for Collision Detection
Platform lavaTrianglePlatform = {-0.69f, -0.64f, 0.15f, 0.1f};
Platform lavaTriangletwoPlatform = {0.64f, 0.69f, 0.15f, 0.1f};


Platform lavaTriangle1 = {-0.5f, -0.4f, 0.05f, 0.0f};
Platform lavaTriangle2 = {-0.4f, -0.3f, 0.05f, 0.0f};
Platform lavaTriangle3 = {-0.3f, -0.2f, 0.05f, 0.0f};
// Define the four lava circles as platforms
Platform lavaCircle1 = {0.10f, 0.14f, 0.14f, 0.10f};
Platform lavaCircle2 = {0.15f, 0.19f, 0.14f, 0.10f};
Platform lavaCircle3 = {0.20f, 0.24f, 0.14f, 0.10f};
Platform lavaCircle4 = {0.25f, 0.29f, 0.14f, 0.10f};
Platform lastRectanglePlatform = {0.55f, 0.63f, 0.21f, 0.18f};  // Define the rectangle bounds


// finish
//Platform secondPartPlatform = {-1.0f, -0.8f, -0.3f, -0.2f}; // Coordinates for 2nd 1st rectangle


// Function to draw a filled circle
void drawCircle(float x_center, float y_center, float radius) {
    int num_segments = 100; // Number of segments to approximate the circle
    glBegin(GL_POLYGON);  // Draw a filled circle using polygon
    for (int i = 0; i < num_segments; i++) {
        float angle = 2 * M_PI * i / num_segments;  // Angle for each segment
        float x = x_center + cos(angle) * radius;   // X position
        float y = y_center + sin(angle) * radius;   // Y position
        glVertex2f(x, y);  // Add the vertex for the circle
    }
    glEnd();
}




bool checkCollision(const Platform& platform) {
    return (playerX + playerRadius > platform.left &&
            playerX - playerRadius < platform.right &&
            playerY - playerRadius <= platform.top &&
            playerY - playerRadius >= platform.bottom);
}
void updatePlayer(int value) {
    if (!levelComplete) {
    velocityY += gravity;
    playerY += velocityY;


    if (moveLeft) {
        playerX -= 0.008f;
    }
    if (moveRight) {
        playerX += 0.008f;
    }

    // Check if player passed a new block
        for (int i = 0; i < 8; i++) {
            if (!blocksPassed[i] && playerX >= blockPositions[i]) {
                score += 10;  //  Add 10 points for passing a block
                blocksPassed[i] = true;
            }
        }




        //  Check if player falls and play fail sound
        if (playerY < 0.0f) {
            playFailSound();
            playerX = -0.9f; // Restart player position
            playerY = 0.28f;
            score = 0;  // Reset score
            for (int i = 0; i < 8; i++) blocksPassed[i] = false; // Reset blocks
        }
        if (playerY < 0.0f) {
    playFailSound();
    resetPlayer(); // Centralized reset
}
if (playerX > -0.5f && playerX < -0.2f && playerY - playerRadius <= 0.1f) {
    resetPlayer(); // Reset when falling into the first hole
}

if (playerX > 0.38f && playerX < 0.43f && playerY - playerRadius <= 0.1f) {
    resetPlayer(); // Reset when falling into the second hole
}
if (checkCollision(lavaTrianglePlatform) || checkCollision(lavaTriangletwoPlatform)) {
            resetPlayer(); // Lava triangles
        }
        if (checkCollision(lavaTriangle1)) {
    resetPlayer(); // Reset when touching the first lava triangle
}


        if (checkCollision(lavaCircle1) || checkCollision(lavaCircle2) ||
            checkCollision(lavaCircle3) || checkCollision(lavaCircle4)) {
            resetPlayer(); // Lava circles
        }

        if (checkCollision(lavaTriangle1) || checkCollision(lavaTriangle2) ||
            checkCollision(lavaTriangle3)) {
            resetPlayer(); // Small lava triangles
        }

        // Check if the player reaches the end flag and play level complete sound
        if (checkLevelComplete()) {
            levelComplete = true;
            playLevelCompleteSound();  // Play sound for level completion
        }



    // Check if player reaches the end
        if (checkLevelComplete()) {
            levelComplete = true;
        }

    }
    // Move Cloud 1 (between -0.8f and 0.8f)
if (moveRightCloud1) {
    cloud1X += cloudSpeed;
    if (cloud1X >= 0.8f) {
        moveRightCloud1 = false;  // Move left after reaching the limit
    }
} else {
    cloud1X -= cloudSpeed;
    if (cloud1X <= -0.8f) {
        moveRightCloud1 = true;  // Move right after reaching the limit
    }
}

// Move Cloud 2 (between -0.8f and 0.8f)
if (moveRightCloud2) {
    cloud2X += cloudSpeed;
    if (cloud2X >= 0.8f) {
        moveRightCloud2 = false;  // Move left after reaching the limit
    }
} else {
    cloud2X -= cloudSpeed;
    if (cloud2X <= -0.8f) {
        moveRightCloud2 = true;  // Move right after reaching the limit
    }
}

// Move Cloud 3 (between -0.8f and 0.8f)
if (moveRightCloud3) {
    cloud3X += cloudSpeed;
    if (cloud3X >= 0.8f) {
        moveRightCloud3 = false;  // Move left after reaching the limit
    }
} else {
    cloud3X -= cloudSpeed;
    if (cloud3X <= -0.8f) {
        moveRightCloud3 = true;  // Move right after reaching the limit
    }
}


// Check collision with the last rectangle
if (checkCollision(lasttopPlatform)) {
    playerY = lasttopPlatform.top + playerRadius;
    velocityY = 0.0f;
    isOnGround = true;
}



    // Move the circle up and down between 0.2f and 0.5f on the Y-axis
if (movingUpCircle) {
    movingCircleY += movingCircleSpeed;
    if (movingCircleY >= 0.6f) {
        movingUpCircle = false;  // Change direction to move down
    }
} else {
    movingCircleY -= movingCircleSpeed;
    if (movingCircleY <= 0.2f) {
        movingUpCircle = true;   // Change direction to move up
    }
}
// Move the circle between -0.07f and -0.45f
if (movingDown) {
    movingCircleX -= movingCircleXSpeed;
    if (movingCircleX <= -0.45f) {
        movingDown = false;  // Switch direction to move up
    }
} else {
    movingCircleX += movingCircleXSpeed;
    if (movingCircleX >= -0.07f) {
        movingDown = true;  // Switch direction to move down
    }
}
// Move the circle between -0.07f and -0.45f
if (movingDownZ) {
    movingCircleZ -= movingCircleZSpeed;
    if (movingCircleZ <= -0.71f) {
        movingDownZ = false;  // Switch direction to move up
    }
} else {
    movingCircleZ += movingCircleZSpeed;
    if (movingCircleZ >= -0.29f) {
        movingDownZ = true;  // Switch direction to move down
    }
}


     // Move the top-left platform between -0.5f and -0.3f
    if (movingRight) {
        topLeftPlatform.left += topLeftPlatformSpeed;
        topLeftPlatform.right += topLeftPlatformSpeed;
        if (topLeftPlatform.right >= -0.35f) {
            movingRight = false;
        }
    } else {
        topLeftPlatform.left -= topLeftPlatformSpeed;
        topLeftPlatform.right -= topLeftPlatformSpeed;
        if (topLeftPlatform.left <= -0.5f) {
            movingRight = true;
        }
    }

    // Move the right top platform between -0.35f and -0.2f
    if (movingleft) {
        topRightPlatform.left += topRightPlatformSpeed;
        topRightPlatform.right += topRightPlatformSpeed;
        if (topRightPlatform.right >= -0.2f) {
            movingleft = false;
        }
    } else {
        topRightPlatform.left -= topRightPlatformSpeed;
        topRightPlatform.right -= topRightPlatformSpeed;
        if (topRightPlatform.left <= -0.35f) {
            movingleft = true;
        }
    }

// Check if the player falls into the first hole and auto-reset
if (playerX > -0.5f && playerX < -0.2f && playerY - playerRadius <= 0.1f) {
    // Auto-reset the player position when falling into the first hole
    playerX = -0.875f;
    playerY = 0.675f;
    velocityY = 0.0f;
    isOnGround = true;  // Ensure the player is on the ground after reset
}
// Check if the player falls into the second hole and auto-reset
else if (playerX > 0.38f && playerX < 0.43f && playerY - playerRadius <= 0.1f) {
    // Auto-reset the player position when falling into the second hole
    playerX = -0.875f;  // Reset to starting X position
    playerY = 0.675f;   // Reset to starting Y position
    velocityY = 0.0f;   // Reset vertical velocity
    isOnGround = true;  // Ensure the player is on the ground after reset
}

// Auto-reset if the player falls off the screen
else if (playerY < -1.0f) {  // Falls below the visible screen
    // Reset position or trigger game over
    playerX = -0.9f;  // Reset to starting position
    playerY = -0.18f;
    velocityY = -0.5f;
    isOnGround = true;
}




    // Check collision with the first platform
    else if (checkCollision(firstPlatform)) {
        playerY = firstPlatform.top + playerRadius;
        velocityY = 0.0f;
        isOnGround = true;
    }
    // Check collision with the second platform
    else if (checkCollision(secondPlatform)) {
        playerY = secondPlatform.top + playerRadius;
        velocityY = 0.0f;
        isOnGround = true;
    }
    // Check collision with the bottom platform
    else if (checkCollision(bottomPlatform)) {
        playerY = bottomPlatform.top + playerRadius;
        velocityY = 0.0f;
        isOnGround = true;
    }
    // Check collision with the moving top-left platform
    else if (checkCollision(topLeftPlatform)) {
        playerY = topLeftPlatform.top + playerRadius;
        velocityY = 0.0f;
        isOnGround = true;
    }
    // Check collision with the right top platform (with hole)
    else if (checkCollision(topRightPlatform)) {
        playerY = topRightPlatform.top + playerRadius;
        velocityY = 0.0f;
        isOnGround = true;
    }
    else if (checkCollision(firstpillerPlatform)) {
        playerY = firstpillerPlatform.top + playerRadius;
        velocityY = 0.0f;
        isOnGround = true;
    }
    else if (checkCollision(firsttopLeftPlatform)) {
        playerY = firsttopLeftPlatform.top + playerRadius;
        velocityY = 0.0f;
        isOnGround = true;
    }
    else if (checkCollision(secondtopLeftPlatform)) {
        playerY = secondtopLeftPlatform.top + playerRadius;
        velocityY = 0.0f;
        isOnGround = true;
    }
    else if (checkCollision(secondpillerPlatform)) {
        playerY = secondpillerPlatform.top + playerRadius;
        velocityY = 0.0f;
        isOnGround = true;
    }
    else if (checkCollision(lasttopPlatform)) {
       playerY = lasttopPlatform.top + playerRadius;
        velocityY = 0.0f;
        isOnGround = true;
    }
 /* else if (checkCollision(secondPartPlatform)) {
    playerY = secondPartPlatform.top + playerRadius;
    velocityY = -0.5f;  // Prevents sliding off
    isOnGround = true;
}
*/
    // Check if the player is colliding with the last rectangle
else if (checkCollision(lastRectanglePlatform)) {
    // Player lands on the rectangle and stops falling
    playerY = lastRectanglePlatform.top + playerRadius;  // Adjust playerY to the top of the rectangle
    velocityY = 0.0f;  // Stop vertical movement (gravity)
    isOnGround = true;  // The player is now on the ground
}

    else if (checkCollision(lavaTrianglePlatform)) {
    // Auto-reset the player position when touching the lava triangle
    playerX = -0.875f;  // Reset to the starting X position
    playerY = 0.675f;   // Reset to the starting Y position
    velocityY = 0.0f;   // Reset vertical velocity
    isOnGround = true;  // Ensure the player is on the ground after reset
}
else if (checkCollision(lavaTriangletwoPlatform)) {
    // Auto-reset the player position when touching the lava triangle
    playerX = -0.875f;  // Reset to the starting X position
    playerY = 0.675f;   // Reset to the starting Y position
    velocityY = 0.0f;   // Reset vertical velocity
    isOnGround = true;  // Ensure the player is on the ground after reset
}


    // Check collision with the first lava triangle
else if (checkCollision(lavaTriangle1)) {
    playerY = lavaTriangle1.top + playerRadius;
    velocityY = 0.0f;
    isOnGround = true;
}
// Check collision with the second lava triangle
else if (checkCollision(lavaTriangle2)) {
    playerY = lavaTriangle2.top + playerRadius;
    velocityY = 0.0f;
    isOnGround = true;
}
// Check collision with the third lava triangle
else if (checkCollision(lavaTriangle3)) {
    playerY = lavaTriangle3.top + playerRadius;
    velocityY = 0.0f;
    isOnGround = true;
}
// Check collision with the first lava circle
else if (checkCollision(lavaCircle1)) {
    // Reset player position or trigger game over
    playerX = -0.875f;
    playerY = 0.675f;
    velocityY = 0.0f;
    isOnGround = true;
}

// Check collision with the second lava circle
else if (checkCollision(lavaCircle2)) {
    playerX = -0.875f;
    playerY = 0.675f;
    velocityY = 0.0f;
    isOnGround = true;
}

// Check collision with the third lava circle
else if (checkCollision(lavaCircle3)) {
    playerX = -0.875f;
    playerY = 0.675f;
    velocityY = 0.0f;
    isOnGround = true;
}

// Check collision with the fourth lava circle
else if (checkCollision(lavaCircle4)) {
    playerX = -0.875f;
    playerY = 0.675f;
    velocityY = 0.0f;
    isOnGround = true;
}

    else {
        isOnGround = false;
    }

    glutPostRedisplay();
    glutTimerFunc(16, updatePlayer, 0);  // Call again after 16ms (~60 FPS)
}


// Handle Key Input for Jumping and Movement
void handleInput(unsigned char key, int x, int y) {
    if (key == 'w' && isOnGround) {  // Spacebar to jump
        velocityY = jumpForce;
        isOnGround = false;
    }

    if (key == 'a') {  // Move left
        playerX -= 0.02f;
    }
    if (key == 'd') {  // Move right
        playerX += 0.02f;
    }
}

// Handler for window-repaint event. Call back when the window first appears and
// whenever the window needs to be re-painted.
void renderBitmapString(float x, float y, float z, void *font, char *string) {
    char *c;
    glRasterPos3f(x, y, z);
    for (c = string; *c != '\0'; c++) {
        glutBitmapCharacter(font, *c);
    }
}


// Function to draw a cloud using multiple circles
void drawCloud(float x, float y) {
    glColor3f(0.5f, 0.3f, 0.2f); // Light gray color for the cloud
    drawCircle(x, y, 0.05f);        // Center circle
    drawCircle(x - 0.06f, y + 0.02f, 0.04f); // Top-left
    drawCircle(x + 0.06f, y + 0.02f, 0.04f); // Top-right
    drawCircle(x - 0.04f, y - 0.03f, 0.03f); // Bottom-left
    drawCircle(x + 0.04f, y - 0.03f, 0.03f); // Bottom-right
}


void display() {
    glClearColor(0.5f, 0.5f, 0.5f, 1.0f); // Set background color
    glClear(GL_COLOR_BUFFER_BIT); // Clear the color buffer (background)
    glPointSize(5.0); // Set point size for future point drawing

    // Drawing the crosshair in the center
    glBegin(GL_LINES);
    glColor3f(0.0f, 0.0f, 0.0f); // Black color
    glVertex2f(0.0f, 1.0f); // Vertical line
    glVertex2f(0.0f, -1.0f);
    glVertex2f(-1.0f, 0.0f); // Horizontal line
    glVertex2f(1.0f, 0.0f);
    glEnd();

    // Draw the rectangle (brick base)
    glBegin(GL_QUADS);
    glColor3f(0.0f, 0.0f, 0.0f); // Black color
    glVertex2f(-1.0f, 1.0f);     // Top-left
    glVertex2f(1.0f, 1.0f);      // Top-right
    glVertex2f(1.0f, 0.0f);      // Bottom-right
    glVertex2f(-1.0f, 0.0f);     // Bottom-left
    glEnd();

    // Drawing brick sections
    glBegin(GL_QUADS);  // Left section
    glColor3f(0.235f, 0.118f, 0.059f); // Nearly burnt dark brown
    glVertex2f(-1.0f, 0.1f);  // Bottom-left
    glVertex2f(-0.95f, 0.1f);  // Bottom-right
    glVertex2f(-0.95f, 1.0f);  // Top-right
    glVertex2f(-1.0f, 1.0f);  // Top-left
    glEnd();

    glBegin(GL_QUADS);  // Right section
    glColor3f(0.235f, 0.118f, 0.059f); // Nearly burnt dark brown
    glVertex2f(1.0f, 0.1f);  // Bottom-left
    glVertex2f(0.95f, 0.1f);  // Bottom-right
    glVertex2f(0.95f, 1.0f);  // Top-right
    glVertex2f(1.0f, 1.0f);  // Top-left
    glEnd();

    // Draw the bottom brick part
    glBegin(GL_QUADS);
    glColor3f(0.235f, 0.118f, 0.059f); // Nearly burnt dark brown
    glVertex2f(-1.0f, 0.0f);  // Bottom-left
    glVertex2f(1.0f, 0.0f);  // Bottom-right
    glVertex2f(1.0f, 0.1f);  // Top-right
    glVertex2f(-1.0f, 0.1f);  // Top-left
    glEnd();

    // Draw the grid inside the brick (vertical lines)
    glColor3f(0.0f, 0.0f, 0.0f); // Black color for the grid lines
    for (float x = -1.0f; x < 1.0f; x += 0.1f) {
        glBegin(GL_LINES);
        glVertex2f(x, 0.0f);  // Bottom point
        glVertex2f(x, 0.1f);  // Top point
        glEnd();
    }

    // Draw the horizontal grid lines
    glBegin(GL_LINES);
    glVertex2f(-1.0f, 0.0f);
    glVertex2f(1.0f, 0.0f);
    glVertex2f(-1.0f, 0.1f);
    glVertex2f(1.0f, 0.1f);
    glEnd();



    // Draw gradient background for first and second quadrants (top half)
    glBegin(GL_QUADS);
    // Top (extremely deep red)
    glColor3f(0.3f, 0.0f, 0.0f); // Extremely deep red
    glVertex2f(-0.95f, 1.0f);     // Top-left
    glVertex2f(0.95f, 1.0f);      // Top-right

    // Middle (smoldering deep orange)
    glColor3f(0.6f, 0.1f, 0.0f); // Smoldering deep orange
    glVertex2f(0.95f, 0.1f);      // Bottom-right of top half
    glVertex2f(-0.95f, 0.1f);     // Bottom-left of top half
    glEnd();

    // Draw glowing lava in the bottom half
    glBegin(GL_QUADS);
    // Top of lava (bright orange)
    glColor3f(1.0f, 0.4f, 0.0f); // Bright orange
    glVertex2f(-0.95f, 0.1f);     // Top-left of lava
    glVertex2f(0.95f, 0.1f);      // Top-right of lava
    glEnd();

    // Draw additional small brick shapes (two rectangles)
    glBegin(GL_QUADS);  // First rectangle
    glColor3f(0.235f, 0.118f, 0.059f); // Nearly burnt dark brown
    glVertex2f(-0.95f, 0.6f);  // Bottom-left
    glVertex2f(-0.80f, 0.6f);  // Bottom-right
    glVertex2f(-0.80f, 0.65f);  // Top-right
    glVertex2f(-0.95f, 0.65f);  // Top-left
    glEnd();

    glBegin(GL_QUADS);  // Second rectangle
    glColor3f(0.235f, 0.118f, 0.059f); // Nearly burnt dark brown
    glVertex2f(-0.95f, 0.35f);  // Bottom-left
    glVertex2f(-0.7f, 0.35f);  // Bottom-right
    glVertex2f(-0.7f, 0.4f);  // Top-right
    glVertex2f(-0.95f, 0.4f);  // Top-left
    glEnd();



    // Draw lava-like triangle
    glBegin(GL_TRIANGLES);
glColor3f(0.8f, 0.1f, 0.0f);
    glVertex2f(-0.69f, 0.1f);
    glVertex2f(-0.64f, 0.1f);
    glVertex2f(-0.665f, 0.15f);
    glEnd();

     // Draw lava-like triangle 2
    glBegin(GL_TRIANGLES);
glColor3f(0.8f, 0.1f, 0.0f);
    glVertex2f(0.69f, 0.1f);
    glVertex2f(0.64f, 0.1f);
    glVertex2f(0.665f, 0.15f);
    glEnd();


    // Draw a small filled circle just above the triangle
glColor3f(1.0f, 0.0f, 0.0f);  // Red color for the circle
    drawCircle(-0.665f, movingCircleY, 0.008f);  // Circle on top of the triangle with a small radius
    drawCircle(-0.665f,0.6f, 0.008f);
    drawCircle(0.665f, movingCircleY, 0.008f);
    drawCircle(0.665f,0.6f, 0.008f);

    // first hole
    glBegin(GL_POLYGON);
    glColor3f(0.0f, 0.0f, 0.0f);
    glVertex2f(-0.5f, 0.0f);
    glVertex2f(-0.2f, 0.0f);
    glVertex2f(-0.2f, 0.1f);
    glVertex2f(-0.5f, 0.1f);
    glEnd();


    // Draw lava-like triangle
    glBegin(GL_TRIANGLES);
    glColor3f(0.8f, 0.1f, 0.0f);
    glVertex2f(-0.5f, 0.0f);
    glVertex2f(-0.4f, 0.0f);
    glVertex2f(-0.45f, 0.05f);
    glEnd();

    // Draw lava-like triangle
    glBegin(GL_TRIANGLES);
    glColor3f(0.5f, 0.3f, 0.1f);
    glVertex2f(-0.4f, 0.0f);
    glVertex2f(-0.3f, 0.0f);
    glVertex2f(-0.35f, 0.05f);
    glEnd();

    // Draw lava-like triangle
    glBegin(GL_TRIANGLES);
    glColor3f(0.8f, 0.1f, 0.0f);
    glVertex2f(-0.3f, 0.0f);
    glVertex2f(-0.2f, 0.0f);
    glVertex2f(-0.25f, 0.05f);
    glEnd();

    //top from the hole
    glBegin(GL_QUADS);
glColor3f(0.235f, 0.118f, 0.059f); // Nearly burnt dark brown
glVertex2f(topLeftPlatform.left, topLeftPlatform.bottom);
glVertex2f(topLeftPlatform.right, topLeftPlatform.bottom);
glVertex2f(topLeftPlatform.right, topLeftPlatform.top);
glVertex2f(topLeftPlatform.left, topLeftPlatform.top);
glEnd();


   // Draw the moving right top platform
glBegin(GL_QUADS);
glColor3f(0.235f, 0.118f, 0.059f); // Nearly burnt dark brown
glVertex2f(topRightPlatform.left, topRightPlatform.bottom);  // Bottom-left
glVertex2f(topRightPlatform.right, topRightPlatform.bottom); // Bottom-right
glVertex2f(topRightPlatform.right, topRightPlatform.top);    // Top-right
glVertex2f(topRightPlatform.left, topRightPlatform.top);     // Top-left
glEnd();


    //piler
     glBegin(GL_QUADS);
    glColor3f(0.235f, 0.118f, 0.059f); // Nearly burnt dark brown
    glVertex2f(0.01f, 0.1f);  // Bottom-left
    glVertex2f(0.08f, 0.1f);  // Bottom-right
    glVertex2f(0.08f, 0.25f);  // Top-right
    glVertex2f(0.01f, 0.25f);  // Top-left
    glEnd();

    //circle lava
    glColor3f(1.0f, 0.0f, 0.0f);  // Red color for the circle
    drawCircle(0.12f, 0.12f, 0.02f);  // Circle on top of the triangle with a small radius
    drawCircle(0.17f, 0.12f, 0.02f);
    drawCircle(0.22f, 0.12f, 0.02f);
    drawCircle(0.27f, 0.12f, 0.02f);

    //upper side of circle of lava
     glBegin(GL_QUADS);
    glColor3f(0.235f, 0.118f, 0.059f); // Nearly burnt dark brown
    glVertex2f(0.1f, 0.3f);  // Bottom-left
    glVertex2f(0.17f, 0.3f);  // Bottom-right
    glVertex2f(0.17f, 0.33f);  // Top-right
    glVertex2f(0.1f, 0.33f);  // Top-left
    glEnd();

     glBegin(GL_QUADS);
    glColor3f(0.235f, 0.118f, 0.059f); // Nearly burnt dark brown
    glVertex2f(0.23f, 0.3f);  // Bottom-left
    glVertex2f(0.30f, 0.3f);  // Bottom-right
    glVertex2f(0.30f, 0.33f);  // Top-right
    glVertex2f(0.23f, 0.33f);  // Top-left
    glEnd();

    //2nd hole
    glBegin(GL_POLYGON);
    glColor3f(0.0f, 0.0f, 0.0f);
    glVertex2f(0.38f, 0.0f);
    glVertex2f(0.43f, 0.0f);
    glVertex2f(0.43f, 0.1f);
    glVertex2f(0.38f, 0.1f);
    glEnd();

     //2nd piler
     glBegin(GL_QUADS);
    glColor3f(0.235f, 0.118f, 0.059f); // Nearly burnt dark brown
    glVertex2f(0.8f, 0.1f);  // Bottom-left
    glVertex2f(0.85f, 0.1f);  // Bottom-right
    glVertex2f(0.85f, 0.25f);  // Top-right
    glVertex2f(0.8f, 0.25f);  // Top-left
    glEnd();

     glBegin(GL_QUADS);  // last rectangle
    glColor3f(0.235f, 0.118f, 0.059f); // Nearly burnt dark brown
    glVertex2f(0.55f, 0.18f);  // Bottom-left
    glVertex2f(0.63f, 0.18f);  // Bottom-right
    glVertex2f(0.63f, 0.21f);  // Top-right
    glVertex2f(0.55f, 0.21f);  // Top-left
    glEnd();

    glBegin(GL_QUADS);  // last end point
    glColor3f(0.235f, 0.118f, 0.059f); // Nearly burnt dark brown
    glVertex2f(0.95f, 0.22f);  // Bottom-left
    glVertex2f(0.9f, 0.22f);  // Bottom-right
    glVertex2f(0.9f, 0.25f);  // Top-right
    glVertex2f(0.95f, 0.25f);  // Top-left
    glEnd();





    drawCloud(cloud1X, 0.8f); // Cloud 1
    drawCloud(cloud2X, 0.7f);  // Cloud 2
    drawCloud(cloud3X, 0.85f); // Cloud 3



//objects
     glColor3f(0.0f, 0.0f, 1.0f);
   drawCircle(playerX, playerY, playerRadius);

   // first hole
    glBegin(GL_POLYGON);
    //glColor3f(1.0f, 0.5f, 0.0f);//y axis color
     glColor3f(0.4f, 0.0f, 0.0f);
    glVertex2f(-1.0f, 0.0f);
    glVertex2f(1.0f, 0.0f);
    glVertex2f(1.0f, -1.0f);
    glVertex2f(-1.0f, -1.0f);
    glEnd();

///2nd part start
glBegin(GL_POLYGON);//  2nd 1st rectangle
    //glColor3f(0.0f, 0.0f, 0.0f);//black
     glColor3f(0.1f, 0.0f, 0.0f);
     // glColor3f(0.8f, 0.2f, 0.0f);
    glVertex2f(-1.0f, -0.2f);
    glVertex2f(-0.8f, -0.2f);
    glVertex2f(-0.8f, -0.3f);
    glVertex2f(-1.0f, -0.3f);
    glEnd();
 glBegin(GL_POLYGON); // 2nd 2 rectangle
   // glColor3f(0.0f, 0.0f, 0.0f);//black
     glColor3f(0.1f, 0.0f, 0.0f);
    glVertex2f(-1.0f, -0.7f);
    glVertex2f(-0.7f, -0.7f);
    glVertex2f(-0.7f, -1.0f);
    glVertex2f(-1.0f, -1.0f);
    glEnd();

    /*// Draw the second part platform
    glBegin(GL_QUADS);
    glColor3f(0.0f, 0.2f, 0.2f); // Brownish color for the platform
    glVertex2f(secondPartPlatform.left, secondPartPlatform.bottom);
    glVertex2f(secondPartPlatform.right, secondPartPlatform.bottom);
    glVertex2f(secondPartPlatform.right, secondPartPlatform.top);
    glVertex2f(secondPartPlatform.left, secondPartPlatform.top);
    glEnd();
*/
glBegin(GL_POLYGON);
   // glColor3f(0.0f, 0.0f, 0.0f);//black
     glColor3f(0.1f, 0.0f, 0.0f);
    glVertex2f(-1.0f, -0.7f);
    glVertex2f(-0.7f, -0.7f);
    glVertex2f(-0.7f, -1.0f);
    glVertex2f(-1.0f, -1.0f);
    glEnd();
glBegin(GL_POLYGON);
    //glColor3f(0.0f, 0.0f, 0.0f);//black
     glColor3f(0.1f, 0.0f, 0.0f);
    //glVertex2f(-0.2f, 0.0f);
    glVertex2f(-0.4f, -0.40f);
    glVertex2f(-0.65f, -0.40f);
    glVertex2f(-0.65f, -0.54f);
     glVertex2f(-0.27f, -0.54f);
      glVertex2f(-0.27f, 0.0f);
       glVertex2f(-0.4f, 0.0f);
    glEnd();

//........
    glBegin(GL_POLYGON);
    //glColor3f(0.0f, 0.0f, 0.0f);//black
     glColor3f(0.1f, 0.0f, 0.0f);
    glVertex2f(-0.6f, -0.75f);
    glVertex2f(-0.45f, -0.75f);
    glVertex2f(-0.45f, -0.8f);
    glVertex2f(-0.6f, -0.8f);
    glEnd();

     glBegin(GL_POLYGON);
    //glColor3f(0.0f, 0.0f, 0.0f);//black
     glColor3f(0.1f, 0.0f, 0.0f);
    glVertex2f(-0.32f, -0.75f);
    glVertex2f(-0.18, -0.75f);
    glVertex2f(-0.18f, -0.8f);
    glVertex2f(-0.32f, -0.8f);
    glEnd();

//.......

    glBegin(GL_POLYGON);
    //glColor3f(0.0f, 0.0f, 0.0f);//black
     glColor3f(0.1f, 0.0f, 0.0f);
    glVertex2f(-0.05f, -1.0f);
    glVertex2f(-0.05f, -0.7f);
    glVertex2f(0.3f, -0.7f);
    glVertex2f(0.3f, -1.0f);
    glEnd();

     glBegin(GL_POLYGON);
    //glColor3f(0.0f, 0.0f, 0.0f);//black
     glColor3f(0.1f, 0.0f, 0.0f);
    glVertex2f(0.15f, -0.52f);
    glVertex2f(0.15f, -0.6f);
    glVertex2f(0.36f, -0.6f);
    glVertex2f(0.36f, -0.52f);
    glEnd();

    glBegin(GL_POLYGON);
    //glColor3f(0.0f, 0.0f, 0.0f);//black
     glColor3f(0.1f, 0.0f, 0.0f);
    glVertex2f(-0.09f, -0.32f);
    glVertex2f(-0.09f, -0.40f);
    glVertex2f(0.1f, -0.40f);
    glVertex2f(0.1f, -0.32f);
    glEnd();

    glBegin(GL_POLYGON);
    //glColor3f(0.0f, 0.0f, 0.0f);//black
     glColor3f(0.1f, 0.0f, 0.0f);
    glVertex2f(0.19f, -0.15f);
    glVertex2f(0.19f, -0.23f);
    glVertex2f(0.42f, -0.23f);
    glVertex2f(0.42f, -0.15f);
    glEnd();

      glBegin(GL_POLYGON);
    //glColor3f(0.0f, 0.0f, 0.0f);//black
     glColor3f(0.1f, 0.0f, 0.0f);
    glVertex2f(0.42f, -0.73f);
    glVertex2f(0.42f, -0.79f);
    glVertex2f(0.6f, -0.79f);
    glVertex2f(0.6f, -0.73f);
    glEnd();

      glBegin(GL_POLYGON);
    //glColor3f(0.0f, 0.0f, 0.0f);//black
     glColor3f(0.1f, 0.0f, 0.0f);
    glVertex2f(0.7f, -1.0f);
    glVertex2f(0.7f, -0.6f);
    glVertex2f(1.0f, -0.6f);
    glVertex2f(1.0f, -1.0f);
    glEnd();

     glLineWidth(5.0f);// Set the line width to 5 pixels
     glColor3f(0.0f, 0.0f, 1.0f);
glBegin(GL_LINES);
    glVertex2f(0.92f, 0.25f);
    glVertex2f(0.92f, 0.33f);
glEnd();

// Draw a small triangular flag at the top of the line
glColor3f(0.0f, 1.0f, 0.0f);  // Green color
// Draw the flag using GL_QUADS (a rectangle)
glBegin(GL_QUADS);
    glVertex2f(flagX, flagY);  // Bottom-left point of the flag
    glVertex2f(flagX, flagY + flagHeight);  // Top-left point of the flag
    glVertex2f(flagX + flagWidth, flagY + flagHeight);  // Top-right point of the flag
    glVertex2f(flagX + flagWidth, flagY);  // Bottom-right point of the flag
glEnd();



    glBegin(GL_TRIANGLES);
    glColor3f(0.8f, 0.1f, 0.0f);
    glVertex2f(-0.7f, -1.0f);
    glVertex2f(-0.48f, -1.0f);
    glVertex2f(-0.58f, -0.9f);
    glEnd();

     glBegin(GL_TRIANGLES);
    glColor3f(0.8f, 0.1f, 0.0f);
    glVertex2f(-0.48f, -1.0f);
    glVertex2f(-0.28f, -1.0f);
    glVertex2f(-0.38f, -0.9f);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3f(0.8f, 0.1f, 0.0f);
    glVertex2f(-0.28f, -1.0f);
    glVertex2f(-0.08f, -1.0f);
    glVertex2f(-0.18f, -0.9f);
    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3f(0.8f, 0.1f, 0.0f);
    glVertex2f(-0.74f, 0.0f);
    glVertex2f(-0.68f, 0.0f);
    glVertex2f(-0.71f, -0.06f);
    glEnd();
//first fire
    glColor3f(1.0f, 0.0f, 0.0f);  // Red color for the circle
    drawCircle(-0.71f,  movingCircleX, 0.008f);  // Circle on top of the triangle with a small radius
    drawCircle(-0.71f, -0.45f, 0.008f);
    drawCircle(-0.16f,  movingCircleX, 0.008f);  // Circle on top of the triangle with a small radius
    drawCircle(-0.16f, -0.45f, 0.008f);
     drawCircle(-0.16f, -0.25f, 0.008f);
    drawCircle(-0.16f, -0.85f, 0.008f);



  glBegin(GL_TRIANGLES);
    glColor3f(0.8f, 0.1f, 0.0f);
    glVertex2f(-0.19f, 0.0f);
    glVertex2f(-0.13f, 0.0f);
    glVertex2f(-0.16f, -0.06f);
    glEnd();


    glBegin(GL_TRIANGLES);
    glColor3f(0.8f, 0.1f, 0.0f);
    glVertex2f(0.35f, -0.23f);
    glVertex2f(0.41f, -0.23f);
    glVertex2f(0.38f, -0.28f);
    glEnd();

    glColor3f(1.0f, 0.0f, 0.0f);  // Red color for the circle
    drawCircle(0.38f, movingCircleZ, 0.008f);  // Circle on top of the triangle with a small radius
    drawCircle(0.38f, -0.71f, 0.008f);

    glColor3f(1.0f, 0.0f, 0.0f);  // Red color for the circle
    drawCircle(0.35f, -0.95f, 0.05f);  // Circle on top of the triangle with a small radius
    drawCircle(0.45f, -0.95f, 0.05f);
    drawCircle(0.55f, -0.95f, 0.05f);
    drawCircle(0.65f, -0.95f, 0.05f);

 // Display score in the top-left corner
   std::stringstream ss;
    ss << "Score: " << score;
   drawText(ss.str().c_str(), -0.9f, 0.9f);


// Display Level Completion Message
    if (levelComplete) {
        drawText("Level 2 Complete!", -0.2f, 0.8f);
    }


    glutSwapBuffers();
    glFlush(); // Render now
}

/* Main function: GLUT runs as a console application starting at main() */
int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitWindowSize(640, 480); // Set the window's initial width & height
    glutInitWindowPosition(80, 50);  // Set the window's initial position according to the monitor
    glutCreateWindow("level 2"); // Create a window with the given title
    glutDisplayFunc(display); // Register display callback handler for window re-paint
    glutKeyboardFunc(handleInput);      // Handle keyboard input (for jumping and movement)
    glutTimerFunc(16, updatePlayer, 0);  // Start the update loop for gravity and collision
    playBackgroundSound();
    glutMainLoop(); // Enter the event-processing loop

    return 0;
}
