#include <windows.h> // for MS Windows
#include <GL/glut.h> // GLUT, include glu.h and gl.h
#include<math.h>>
#include<cstdio>
#include <GL/gl.h>
#include <cmath>
#define PI   3.14159265358979323846

void initGL()
{
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f); // Black and opaque
}

GLfloat position = 0.0f;
GLfloat speed = 0.01f;
void update(int value)
{
    if(position <-1.3)
        position = 1.50f;
    position -= speed;

	glutPostRedisplay();
	glutTimerFunc(100, update, 0);
}
GLfloat position4 = 0.0f; // Start at x = 1.0
GLfloat speed4 = 0.005f;   // Speed of movement

void update4(int value)
{
    if (position4 < -1.5f) // Reset position when it goes out of bounds
        position4 = 1.9f;

    position4 -= speed4; // Move left

    glutPostRedisplay();              // Redraw the scene
    glutTimerFunc(16, update4, 0);    // Call update4 after 16ms (~60 FPS)
}

//*********************
GLfloat position1 = 0.0f;
GLfloat speed1 = 0.1f;
void update1(int value)
{
    if(position1 <-1.365)
        position1 = 1.0f;
    position1 -= speed1;

	glutPostRedisplay();
	glutTimerFunc(100, update1, 0);
}
//******************
GLfloat position2 = -0.15f;  // Start at the top (positive Y-axis)
GLfloat speed2 = 0.015f;     // Speed at which it moves

void update2(int value)
{
    if(position2 < -0.35f)  // When it reaches the bottom (negative Y-axis), reset to the top
        position2 = -0.015f;

    position2 -= speed2;  // Move downward along the Y-axis (decrease position)

    glutPostRedisplay();  // Redraw the scene
    glutTimerFunc(100, update2, 0);  // Call update2 again after 100 ms
}
//***********************************************
/*
float x1 = -2.0f, x2 = 2.0f; // Initial positions of rectangles
static int flag = 1;         // Direction control flag

void initRendering() {
    glEnable(GL_DEPTH_TEST); // Enable depth testing for 3D rendering
}

void reshape(int w, int h) {
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0, (float)w / (float)h, 1.0, 200.0);
}

void drawRectangle1() {
    glColor3f(1.0f, 0.0f, 0.0f); // Red rectangle
    glPushMatrix();
    glTranslatef(x1, 0.0f, -5.0f); // Position the rectangle
    glBegin(GL_QUADS);
    glVertex3f(-0.2f, -0.2f, 0.0f);
    glVertex3f(0.2f, -0.2f, 0.0f);
    glVertex3f(0.2f, 0.2f, 0.0f);
    glVertex3f(-0.2f, 0.2f, 0.0f);
    glEnd();
    glPopMatrix();
}

void drawRectangle2() {
    glColor3f(0.0f, 0.0f, 1.0f); // Blue rectangle
    glPushMatrix();
    glTranslatef(x2, 0.0f, -5.0f); // Position the rectangle
    glBegin(GL_QUADS);
    glVertex3f(-0.2f, -0.2f, 0.0f);
    glVertex3f(0.2f, -0.2f, 0.0f);
    glVertex3f(0.2f, 0.2f, 0.0f);
    glVertex3f(-0.2f, 0.2f, 0.0f);
    glEnd();
    glPopMatrix();
}
void update3(int value) {
    if (flag) {
        x1 += 0.005f;
        x2 -= 0.005f;
        if (x1 > -0.35f)
            flag = 0;
    }
    else {
        x1 -= 0.005f;
        x2 += 0.005f;
        if (x1 < -2.0f)
            flag = 1;
    }

    glutPostRedisplay();      // Request a redraw
    glutTimerFunc(16, update3, 0); // Call update every 16ms (~60 FPS)
}*/

//***********************************************
// Function to draw a Rectangle
void drawRectangle(float x1, float y1, float x2, float y2) {
    glBegin(GL_POLYGON);
    glColor3f(0.5f, 0.5f, 0.5f); // Set the color to gray
    glVertex2f(x1, y1);
    glVertex2f(x1, y2);
    glVertex2f(x2, y2);
    glVertex2f(x2, y1);
    glEnd();

    glColor3f(0.0f, 0.0f, 0.0f); // Set the color to black
    glBegin(GL_LINE_LOOP);
    glVertex2f(x1, y1);
    glVertex2f(x1, y2);
    glVertex2f(x2, y2);
    glVertex2f(x2, y1);
    glEnd();
}

// Function to draw a Triangle with a fixed red color
void drawTriangle(float x1, float y1, float x2, float y2, float x3, float y3) {
    glColor3f(1.0f, 0.0f, 0.0f); // Set the color to red (RGB: 1.0, 0.0, 0.0)
    glBegin(GL_TRIANGLES);
    glVertex2f(x1, y1);
    glVertex2f(x2, y2);
    glVertex2f(x3, y3);
    glEnd();

    glColor3f(0.0f, 0.0f, 0.0f); // Set outline color to black
    glBegin(GL_LINE_LOOP); // Draw the outline of the triangle
    glVertex2f(x1, y1);
    glVertex2f(x2, y2);
    glVertex2f(x3, y3);
    glEnd();
}
// Function to draw a circle
void drawCircle(GLfloat x, GLfloat y, GLfloat radius) {
    int i;
    int triangleAmount = 200; // Number of lines used to draw the circle
    GLfloat twicePi = 2.0f * PI;

    glBegin(GL_TRIANGLE_FAN);
        glVertex2f(x, y); // Center of circle
        for(i = 0; i <= triangleAmount; i++) {
            glVertex2f(x + (radius * cos(i * twicePi / triangleAmount)),
                       y + (radius * sin(i * twicePi / triangleAmount)));
        }
    glEnd();
}




void display() {
    glClearColor(0.529f, 0.808f, 0.922f, 1.0f); // Set background color to skyblue and opaque
    glClear(GL_COLOR_BUFFER_BIT); // Clear the color buffer (background)

    //CLoud
    {
    glPushMatrix();
    glTranslatef(position,0.0f, -1.0f);

    glColor3f(1.0f, 1.0f, 1.0f); // Set color to white
    drawCircle(0.0f, 0.75f, 0.1f); // First circle
    drawCircle(0.05f, 0.8f, 0.1f); // First circle
    drawCircle(0.09f, 0.75f, 0.1f); // First circle

    glPopMatrix();
    }
    {
    glPushMatrix();
    glTranslatef(position4,0.0f, -1.0f);

    glColor3f(1.0f, 1.0f, 1.0f); // Set color to white
    drawCircle(-0.1f, 0.8f, 0.15f); // First circle
    drawCircle(-0.3f, 0.75f, 0.1f); // First circle
    drawCircle(0.1f, 0.75f, 0.15f); // First circle

    glPopMatrix();
    }

    //PLAYER
    glColor3f(0.0f, 0.65f, 0.0f); // Set color to white
    drawCircle(-0.95f, -0.85f, 0.04788f); // First circle

    for (float x = -1.0f; x < -0.5f; x += 0.1f) {
        drawRectangle(x, 0.3f, x + 0.1f, 0.2f);
        // Drawing triangles with different positions
        drawTriangle(-0.75f, 0.2f, -0.65f, 0.2f, -0.7f, 0.15f);
        {
        glPushMatrix();
        glTranslatef(0.0f, position2, 0.0f);  // Translate along the Y-axis

        glColor3f(1.0f, 0.0f, 0.0f); // Set color to red
        drawCircle(-0.7f, 0.15f, 0.015f); // First circle

        glPopMatrix();
        }

    }
    for (float x = -1.0f; x < 1.0f; x += 0.1f) {
        drawRectangle(x, -1.0f, x + 0.1f, -0.9f);
    }
    for (float x = -0.65f; x < -0.45f; x += 0.1f) {
        drawRectangle(x, -0.9f, x + 0.1f, -0.8f);
    }
    for (float x = 0.7f; x < 0.8f; x += 0.1f) {
        drawRectangle(x, -0.75f, x + 0.1f, -0.65f);
    }
    for (float x = 0.2f; x < 0.4f; x += 0.1f) {
        drawRectangle(x, -0.75f, x + 0.1f, -0.65f);
    }
    drawTriangle(0.4f, -0.75f, 0.45f, -0.75f, 0.425f, -0.7f);
    drawTriangle(0.45f, -0.75f, 0.5f, -0.75f, 0.475f, -0.7f);
    drawTriangle(0.5f, -0.75f, 0.55f, -0.75f, 0.525f, -0.7f);
    drawTriangle(0.55f, -0.75f, 0.6f, -0.75f, 0.575f, -0.7f);
    drawTriangle(0.6f, -0.75f, 0.65f, -0.75f, 0.625f, -0.7f);
    drawTriangle(0.65f, -0.75f, 0.7f, -0.75f, 0.675f, -0.7f);

    for (float x = 0.5f; x < 0.6f; x += 0.01f) {
        drawRectangle(x, -0.6f, x + 0.01f, -0.57f);
    }

    for (float x = 0.1f; x < 0.3f; x += 0.01f) {
        drawRectangle(x, -0.4f, x + 0.01f, -0.43f);
    }
    for (float x = -0.3f; x < -0.1f; x += 0.01f) {
        drawRectangle(x, -0.4f, x + 0.01f, -0.43f);
    }
    for (float x = 0.85f; x < 1.0f; x += 0.01f) {
        drawRectangle(x, -0.57f, x + 0.01f, -0.54f);
    }
    for (float x = 0.8f; x < 1.0f; x += 0.1f) {
        drawRectangle(x, -0.0f, x + 0.1f, -0.1f);
        // Drawing triangles with different positions
        drawTriangle(0.92f, -0.1f, 0.82f, -0.1f, 0.87f, -0.15f);
        {
        glPushMatrix();
        glTranslatef(0.0f, position2, 0.0f);  // Translate along the Y-axis

        glColor3f(1.0f, 0.0f, 0.0f); // Set color to red
        drawCircle(0.87f, -0.15f, 0.015f); // First circle

        glPopMatrix();
        }
    }
    for (float x = -1.0f; x < -0.8f; x += 0.1f) {
        drawRectangle(x, -0.35f, x + 0.1f, -0.25f);
    }
    for (float x = -0.65f; x < 0.75f; x += 0.1f) {
        drawRectangle(x, -0.2f, x + 0.1f, -0.1f);
    }
    for (float x = -0.5f; x < -0.1f; x += 0.1f) {
        drawRectangle(x, -0.1f, x + 0.1f, -0.0f);

        drawTriangle(0.0f, -0.1f, 0.05f, -0.1f, 0.025f, -0.05f);
        drawTriangle(0.05f, -0.1f, 0.1f, -0.1f, 0.075f, -0.05f);
        drawTriangle(0.1f, -0.1f, 0.15f, -0.1f, 0.125f, -0.05f);
        drawTriangle(0.15f, -0.1f, 0.2f, -0.1f, 0.175f, -0.05f);
        drawTriangle(0.7f, -0.1f, 0.75f, -0.1f, 0.725f, -0.05f);
    }
    for (float x = 0.2f; x < 0.7f; x += 0.1f) {
        drawRectangle(x, -0.1f, x + 0.1f, -0.0f);
    }

    // Drawing triangles with different positions
    drawTriangle(1.0f, -0.8f, 1.0f, -0.9f, 0.95f, -0.85f);
    {
    glPushMatrix();
    glTranslatef(position1,0.0f, 0.0f);

    glColor3f(1.0f, 0.0f, 0.0f); // Set color to white
    drawCircle(0.95f, -0.85f, 0.015f); // First circle

    glPopMatrix();
    }
    // draw a circle
    glColor3f(1.0f, 0.0f, 0.0f); // Set color to white
    drawCircle(0.5f, 0.2f, 0.015f); // First circle

    glBegin (GL_LINES);
    glColor3f(1.0f, 0.0f, 0.0f);
    glVertex2f(0.5f, 0.2f);
    glVertex2f(0.5f, 0.05f);
    glEnd();
    // draw a circle
    glColor3f(1.0f, 0.0f, 0.0f); // Set color to white
    drawCircle(-0.3f, 0.2f, 0.015f); // First circle
    glBegin (GL_LINES);
    glColor3f(1.0f, 0.0f, 0.0f);
    glVertex2f(-0.3f, 0.2f);
    glVertex2f(-0.3f, 0.35f);
    glEnd();


    for (float x = 0.89f; x < 0.98f; x += 0.01f) {
        drawRectangle(x, 0.28f, x + 0.01f, 0.25f);
    }

    for (float x = -0.4f; x < 0.8f; x += 0.1f) {
        drawRectangle(x, 0.4f, x + 0.1f, 0.5f);
        drawTriangle(-0.2f, 0.5f, -0.25f, 0.5f, -0.225f, 0.55f);
        drawTriangle(0.0f, 0.5f, 0.05f, 0.5f, 0.025f, 0.55f);
        drawTriangle(0.05f, 0.5f, 0.1f, 0.5f, 0.075f, 0.55f);
        drawTriangle(0.2f, 0.5f, 0.25f, 0.5f, 0.225f, 0.55f);
        drawTriangle(0.25f, 0.5f, 0.3f, 0.5f, 0.275f, 0.55f);
        drawTriangle(0.5f, 0.5f, 0.55f, 0.5f, 0.525f, 0.55f);
    }

    glBegin (GL_LINES);
    glColor3f(1.0f, 0.0f, 1.0f);
    glVertex2f(-0.88f, 0.3f);
    glVertex2f(-0.88f, 0.625f);
    glEnd();
    drawTriangle(-0.88f, 0.62f, -0.88f, 0.5f, -0.75f, 0.56f);
//glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Draw the first rectangle
//drawRectangle1();

    // Draw the second rectangle
//drawRectangle2();

//glutSwapBuffers(); // Swap front and back buffers for smooth rendering

    glFlush(); // Render now
}
// Main function: GLUT runs as a console application starting at main()
int main(int argc, char** argv) {
    glutInit(&argc, argv);
//glutInitDisplayMode(GLUT_DOUBLE|GLUT_RGB|GLUT_DEPTH);

    glutInitWindowSize(640, 480); // Set the window's initial width & height
    glutInitWindowPosition(80, 50);  // Set the window's initial position according to the monitor
    //glutCreateWindow("Translation Animation");
    glutCreateWindow("OpenGL Setup Test"); // Create a window with the given title
//initRendering();
    glutDisplayFunc(display); // Register display callback handler for window re-paint
    glutIdleFunc(display);
//glutReshapeFunc(reshape);
    glutTimerFunc(100, update, 0);
    glutTimerFunc(100, update1, 0);
    glutTimerFunc(100, update2, 0);
    glutTimerFunc(100, update4, 0);
//glutTimerFunc(16, update3, 0); // Start the animation
    glutMainLoop(); // Enter the event-processing loop

    return 0;
}
